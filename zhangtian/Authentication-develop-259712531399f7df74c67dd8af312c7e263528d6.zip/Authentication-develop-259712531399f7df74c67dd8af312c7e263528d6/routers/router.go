package routers

import (
	"etecity/Authentication/controllers"
	"etecity/Authentication/controllers/user"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/context"
)

func init() {
	beego.Router("/", &controllers.BaseController{})
	beego.Router("/user/register", &user.RegisterController{})
	beego.Router("/user/register/check", &user.RegisterController{}, "post:Register")

	beego.Router("/user/login", &user.LoginController{})
	beego.Router("/user/login/check", &user.LoginController{}, "post:Login")

	beego.Router("/userd/logout", &user.LogindController{}, "*:Logout")
	beego.Router("/userd/info", &user.LogindController{})

	beego.Router("/userd/change", &user.ChangeController{})
	beego.Router("/userd/change/check", &user.ChangeController{}, "post:ChangePWD")

	var FilterUser = func(ctx *context.Context) {
		_, ok := ctx.Input.Session("username").(string)
		if !ok {
			ctx.Redirect(302, beego.URLFor("LoginController.Get"))
		}
	}
	beego.InsertFilter("/userd/*", beego.BeforeRouter, FilterUser)
}
