package controllers

import (
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/logs"
	"github.com/astaxie/beego/validation"
)

type BaseController struct {
	beego.Controller
}

func (c *BaseController) Get() {
	c.TplName = "index.tpl"
	c.Render()
}

func (c *BaseController) CheckError(err error) bool {
	if err != nil {
		logs.Error("request %s from %s %v", c.Ctx.Input.URI(), c.Ctx.Input.Refer(), err)
		return false
	}
	return true
}

// 保存Form数据错误信息到flash
func (c *BaseController) ValidFormError(em map[string][]*validation.Error) {
	result := map[string]string{}
	for k, v := range em {
		result[k] = v[0].Error()
	}
	flash := beego.NewFlash()
	flash.Data = result
	flash.Store(&c.Controller)
}
