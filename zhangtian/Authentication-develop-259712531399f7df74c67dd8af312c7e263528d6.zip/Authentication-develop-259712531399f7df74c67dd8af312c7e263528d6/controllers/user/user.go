package user

import (
	"etecity/Authentication/controllers"
	"etecity/Authentication/models"
	"fmt"
	"strings"
	"time"

	"github.com/astaxie/beego"
	"github.com/astaxie/beego/logs"
)

type UserController struct {
	controllers.BaseController
	username string
}

func (c *UserController) Prepare() {
	username := c.GetSession("username")
	if username != nil {
		c.username = username.(string)
	}
	beego.ReadFromRequest(&c.Controller)
}

func (c *UserController) getIP() string {
	input := c.Ctx.Input
	ips := input.Proxy()
	if len(ips) > 0 && ips[0] != "" {
		return ips[0]
	}
	ip := strings.Split(c.Ctx.Request.RemoteAddr, ":")
	if len(ip) > 0 && len(ip[0]) >= 7 {
		return ip[0]
	}
	return "127.0.0.1"
}

// add user operation logs
func (c *UserController) Finish() {
	uri := c.Ctx.Input.URI()
	refer := c.Ctx.Input.Refer()
	name := c.username
	detail := fmt.Sprintf("%v sucess in %s", refer, c.getIP())
	switch uri {
	case beego.URLFor("LoginController.Login"): // login op
		if len(c.Data["flash"].(map[string]string)) > 0 { // 不存在的用户
			if c.Data["flash"].(map[string]string)["username"] != "" {
				logs.Debug("no user")
				return
			}
			detail = fmt.Sprintf("%v fail in %s", refer, c.getIP())
		}
		models.AddNewOpLog(name, time.Now(), "Login", detail)
	case beego.URLFor("LogindController.Logout"): // logout op
		if name == "" {
			return
		}
		models.AddNewOpLog(name, time.Now(), "Logout", "")
	case beego.URLFor("RegisterController.Register"): // register op
		if len(c.Data["flash"].(map[string]string)) > 0 {
			return
		}
		models.DropOpLogs(name)
		models.AddNewOpLog(name, time.Now(), "Register", detail)
	case beego.URLFor("ChangeController.ChangePWD"): // chang password
		if len(c.Data["flash"].(map[string]string)) > 0 {
			detail = fmt.Sprintf("%v faild in %s", refer, c.getIP())
		}
		models.AddNewOpLog(name, time.Now(), "ChangePWD", detail)
	}
}
