package user

import (
	"etecity/Authentication/models"

	"github.com/astaxie/beego"
	"github.com/astaxie/beego/validation"
)

type ChangeController struct {
	LogindController
}

func (c *ChangeController) Get() {
	c.Data["Form"] = &models.ChangPasswordForm{}
	c.TplName = "changePassword.html"
	c.Render()
}

func (c *ChangeController) ChangePWD() {
	changeForm := &models.ChangPasswordForm{}
	if !c.CheckError(c.ParseForm(changeForm)) {
		c.Redirect(c.Ctx.Input.Refer(), 302)
		return
	}

	valid := validation.Validation{}
	b, _ := valid.Valid(changeForm)
	if !b {
		c.ValidFormError(valid.ErrorsMap)
		c.Redirect(c.Ctx.Input.Refer(), 302)
		return
	}

	username := c.username
	if username == "" {
		c.Redirect(beego.URLFor("LoginController.Get"), 302)
		return
	}

	if !models.ChangePassword(username, changeForm.OldPassword, changeForm.NewPassword) {
		valid.SetError("Error", "password error")
		c.ValidFormError(valid.ErrorsMap)
		c.Redirect(c.Ctx.Input.Refer(), 302)
		return
	}
	c.Redirect(beego.URLFor("LogindController.Logout"), 302)
	return
}
