package user

import (
	"etecity/Authentication/models"

	"github.com/astaxie/beego"
)

type LoginController struct {
	UserController
}

func (c *LoginController) Get() {
	if c.username != "" {
		c.Redirect(beego.URLFor("LogindController.Logout"), 302)
		return
	}
	c.Data["Form"] = &models.LoginForm{}
	c.TplName = "login.html"
	c.Render()
}

func (c *LoginController) Login() {
	userlogin := &models.LoginForm{}

	if !c.CheckError(c.ParseForm(userlogin)) {
		c.Redirect(c.Ctx.Input.Refer(), 302)
		return
	}
	c.DelSession("username")
	flash := beego.NewFlash()
	pass, name := models.Login(userlogin.Username, userlogin.Password)
	if name == "" {
		flash.Data = map[string]string{"username": "not exit"}
		flash.Store(&c.Controller)
		c.Redirect(c.Ctx.Input.Refer(), 302)
		return
	}
	if !pass {
		flash.Data = map[string]string{"password": "password error"}
		flash.Store(&c.Controller)
		c.username = userlogin.Username
		c.Redirect(c.Ctx.Input.Refer(), 302)
		return
	}
	c.username = userlogin.Username
	c.SetSession("username", userlogin.Username)
	c.Redirect(beego.URLFor("LogindController.Get"), 302)
	return
}
