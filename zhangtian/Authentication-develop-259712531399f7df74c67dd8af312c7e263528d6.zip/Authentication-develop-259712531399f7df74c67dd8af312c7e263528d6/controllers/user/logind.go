package user

import "github.com/astaxie/beego"

type LogindController struct {
	UserController
}

func (c *LogindController) Get() {
	c.TplName = "userInfo.html"
	c.Data["username"] = c.username
	c.Render()
}

func (c *LogindController) Logout() {
	c.Data["username"] = c.username
	c.DestroySession()
	c.Redirect(beego.URLFor("LoginController.Get"), 302)
	return
}
