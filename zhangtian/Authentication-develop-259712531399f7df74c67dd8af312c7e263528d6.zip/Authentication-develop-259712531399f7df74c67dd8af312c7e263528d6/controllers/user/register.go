package user

import (
	"etecity/Authentication/models"

	"github.com/astaxie/beego"
	"github.com/astaxie/beego/validation"
)

type RegisterController struct {
	UserController
}

func (c *RegisterController) Get() {
	c.Data["Form"] = &models.RegisterLoginForm{}
	c.Data["Form_Info"] = &models.RegisterInfoForm{}
	c.TplName = "register.html"
	c.Render()
}

func (c *RegisterController) Register() {
	loginForm := &models.RegisterLoginForm{}
	infoForm := &models.RegisterInfoForm{}

	if !c.CheckError(c.ParseForm(loginForm)) || !c.CheckError(c.ParseForm(infoForm)) {
		c.Redirect(c.Ctx.Input.Refer(), 302)
		return
	}
	valid := validation.Validation{}
	b, _ := valid.Valid(loginForm)
	b, _ = valid.Valid(infoForm)
	if !b {
		c.ValidFormError(valid.ErrorsMap)
		c.Ctx.Redirect(302, c.Ctx.Input.Refer())
		return
	}
	userInfo := &models.UserInfo{
		Username: loginForm.Username,
		Password: loginForm.Password,
		Info:     *infoForm,
	}
	un := models.AddUser(userInfo)
	if un != userInfo.Username {
		valid.SetError("Error", "the username have exit")
		c.ValidFormError(valid.ErrorsMap)
		c.Redirect(c.Ctx.Input.Refer(), 302)
		return
	} else {
		c.username = userInfo.Username
		c.SetSession("username", userInfo.Username)
		c.Redirect(beego.URLFor("LogindController.Get"), 302)
		return
	}

}
