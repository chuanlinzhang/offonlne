package models

import "testing"
import (
	"etecity/Authentication/models/redisDB"
	"fmt"
	"github.com/astaxie/beego/logs"
)

func TestAddUser(t *testing.T) {
	u := &UserInfo{Username: "tab", Password: "admin"}
	AddUser(u)
}

func TestGetUserLogin(t *testing.T) {
	fmt.Println(getUserLogin("tab"))
}

func TestSetUserPassword(t *testing.T) {
	err := setUserPassword("tab", "ssd")
	if err != nil {
		t.Error(err)
	}
	err = setUserPassword("noname", "ababab")
	if err != nil {
		t.Error(err)
	}
}

func TestUpdateUserAll(t *testing.T) {
	u := &UserInfo{Username: "tab", Password: "admin", Salt: "xxxxxxxxxxx"}
	UpdateUserAll("tab", u)
	fmt.Println(getUserLogin("tab"))
}

func TestDeleteUser(t *testing.T) {
	if err := DeleteUser("tab"); err != nil {
		t.Error(err)
	}
	fmt.Println(getUserLogin("tab"))
}

func TestGetUserAll(t *testing.T) {
	u := &UserInfo{Username: "tab", Password: "admin"}
	AddUser(u)
	fmt.Println(GetUserAll("tab"))
}

func TestUserExit(t *testing.T) {
	u := &UserInfo{Username: "tabzhang", Password: "admin"}
	AddUser(u)
	fmt.Println(getUserLogin("tabzhang"))
	fmt.Println(userExit("tabzhang"))
}

func TestTTL(t *testing.T) {
	c, err := redisDB.GetConn()
	if err != nil {
		logs.Error("error connect to redis ", err)
		return
	}
	r, err := c.Do("TTL", "tabzhang")
	if err != nil {
		fmt.Println(err)
		return
	}
	fmt.Println("ttl: ", r.(int64))
}
