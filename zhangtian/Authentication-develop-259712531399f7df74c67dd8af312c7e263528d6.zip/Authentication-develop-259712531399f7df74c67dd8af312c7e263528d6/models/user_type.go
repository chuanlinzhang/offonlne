package models

import (
	"github.com/astaxie/beego/validation"
	"strings"
)

type FormInterface interface {
	validation.ValidFormer
}

type LoginForm struct {
	Username string `json:"username" form:"username" valid:"Required;"`
	Password string `json:"password" form:"password,password," valid:"Required;"`
}

type ChangPasswordForm struct {
	OldPassword   string `json:"password" form:"password,password," valid:"Required;"`
	NewPassword   string `json:"newPassword" form:"newPassword,password,NewPassword:(MinLength 8 & MaxLength 16)" valid:"Required;MinSize(8);MaxSize(16)"`
	ReNewPassword string `json:"rePassword" form:"rePassword,password," valid:"Required;MinSize(8);MaxSize(16)"`
}

type RegisterLoginForm struct {
	Username   string `form:"username,text,Username:(MinLength 8 & MaxLength 16 AlphaNumeric)" valid:"AlphaNumeric;Required;MinSize(8);MaxSize(16)"`
	Password   string `form:"password,password,Password:(MinLength 8 & MaxLength 16)" valid:"Required;MinSize(8);MaxSize(16)"`
	RePassword string `form:"Re-Password,password," valid:"Required;MinSize(8);MaxSize(16)"`
}

type RegisterInfoForm struct {
	Email string `json:"email" form:"email,text,Email" valid:"Email;MaxSize(100)"`
}

func (cpf *ChangPasswordForm) Valid(v *validation.Validation) {
	if strings.Compare(cpf.NewPassword, cpf.ReNewPassword) != 0 {
		v.SetError("Err-Password", "两次密码不一样")
	}
}

func (rlf *RegisterLoginForm) Valid(v *validation.Validation) {
	if strings.Compare(rlf.Password, rlf.RePassword) != 0 {
		v.SetError("Err-Password", "两次密码不一样")
	}
}

func (rif *RegisterInfoForm) Valid(v *validation.Validation) {

}
