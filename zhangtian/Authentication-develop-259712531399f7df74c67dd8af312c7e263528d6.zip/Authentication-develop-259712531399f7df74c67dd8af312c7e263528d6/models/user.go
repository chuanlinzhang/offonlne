package models

import (
	"etecity/Authentication/models/redisDB"
	"reflect"
	"strings"
	"time"

	"github.com/astaxie/beego/logs"
	"github.com/garyburd/redigo/redis"
	"golang.org/x/crypto/scrypt"
	"fmt"
)

type UserInfo struct {
	Username string `json:"username"`
	Password string `json:"password"`
	Salt     string `json:"salt"`
	Info     RegisterInfoForm
}

// getMD5 translate str to md5 hex str
//func getMD5(str string) string {
//	md5Password := md5.New()
//	io.WriteString(md5Password, str)
//	buffer := bytes.NewBuffer(nil)
//	fmt.Fprintf(buffer, "%x", md5Password.Sum(nil))
//	return buffer.String()
//}

func getScryptKey(dest, salt string) string {
	dk, _ := scrypt.Key([]byte(dest), []byte(salt), 32768, 8, 1, 32)
	return fmt.Sprintf("%x", dk)
}

// sendStructField sent all of obj's element to redis pipe,
// if the element is struct call itself. not flush.
func sendStructField(c redis.Conn, hashKey string, obj interface{}) error {
	objT := reflect.TypeOf(obj)
	objV := reflect.ValueOf(obj)
	if reflect.Ptr == objT.Kind() {
		objT, objV = objT.Elem(), objV.Elem()
	}
	for i := 0; i < objT.NumField(); i++ {
		t, v := objT.Field(i), objV.Field(i)
		switch v.Kind() {
		case reflect.Struct:
			if err := sendStructField(c, hashKey, v.Interface()); err != nil {
				return err
			}
		default:
			logs.Debug("HSET %s %s %s\n", hashKey, t.Name, v.Interface())
			if err := c.Send("HSET", hashKey, t.Name, v.Interface()); err != nil {
				break
			}
		}
	}
	return nil
}

// getUserLogin return the user's password and salt.
// if can not find the user return two empty str.
func getUserLogin(username string) (password, salt string) {
	c, err := redisDB.GetConn()
	if err != nil {
		logs.Error("error connect to redis ", err)
		return
	}
	r, err := redis.Values(c.Do("HMGET", username, "Password", "Salt"))
	if err != nil {
		return
	}
	if len(r) != 2 {
		return
	}
	if r[0] != nil {
		password = string(r[0].([]uint8))
	}
	if r[1] != nil {
		salt = string(r[1].([]uint8))
	}
	return
}

// setUserPassword chang user's password(md5).
func setUserPassword(username, password string) error {
	c, err := redisDB.GetConn()
	if err != nil {
		return err
	}
	r, err := c.Do("HSET", username, "Password", password)
	if err != nil {
		return err
	}
	logs.Debug(r)
	return nil
}

// GetUserAll get user's all information as a map[string]string.
func GetUserAll(username string) (um map[string]string, err error) {
	c, err := redisDB.GetConn()
	if err != nil {
		logs.Error("error connect to redis ", err)
		return nil, err
	}
	defer c.Close()
	vs, err := redis.Values(c.Do("HGETALL", username))
	if err != nil {
		return nil, err
	}
	if len(vs) <= 0 {
		return nil, nil
	}
	um = map[string]string{}
	key := string(vs[0].([]uint8))
	for i, v := range vs {
		logs.Debug(i, ":", string(v.([]uint8)))
		if i%2 != 0 {
			um[key] = string(v.([]uint8))
		} else {
			key = string(v.([]uint8))
		}
	}
	return
}

// UpdateUserAll update the user's all information.
func UpdateUserAll(username string, uu *UserInfo) error {
	c, err := redisDB.GetConn()
	if err != nil {
		logs.Error("error connect to redis ", err)
		return err
	}
	defer c.Close()
	if err := sendStructField(c, username, uu); err != nil {
		logs.Error(err)
		return err
	}
	if err := c.Flush(); err != nil {
		logs.Error(err)
		return err
	}
	return nil
}

// DeleteUser delete a user.
// if can nit find not return error
func DeleteUser(username string) error {
	c, err := redisDB.GetConn()
	if err != nil {
		logs.Error("error connect to redis ", err)
		return err
	}
	defer c.Close()
	r, err := c.Do("DEL", username)
	if err != nil {
		return err
	}
	logs.Debug(r)

	return nil
}

// userExit return true if user exit.
// else return false.
func userExit(username string) bool {
	c, err := redisDB.GetConn()
	if err != nil {
		logs.Error("error connect to redis ", err)
		return true
	}
	defer c.Close()
	r, err := c.Do("EXISTS", username)
	if err != nil {
		return false
	}
	num := r.(int64)
	if num == 0 {
		return false
	}
	return true
}

// AddUser add a new user if the user exit or have some error return "".
// if no error return username.
func AddUser(u *UserInfo) string {
	c, err := redisDB.GetConn()
	if err != nil {
		logs.Error("error connect to redis ", err)
		return ""
	}
	defer c.Close()
	if userExit(u.Username) { // 已经存在
		return ""
	}
	u.Salt = getScryptKey(time.Now().String(), time.Now().String())
	//u.Salt = getMD5(time.Now().String())
	u.Password = getScryptKey(u.Password, u.Salt)
	if err := sendStructField(c, u.Username, u); err != nil {
		logs.Error(err)
		return ""
	}
	if err := c.Flush(); err != nil {
		logs.Error(err)
		return ""
	}
	return u.Username

}

func ChangePassword(username, password, newPassword string) bool {
	dbPwd, dbSalt := getUserLogin(username)
	if dbPwd == "" || dbSalt == "" {
		logs.Error("can not find the user ", username)
		return false
	}
	if strings.Compare(getScryptKey(password, dbSalt), dbPwd) != 0 {
		logs.Error("password error")
		return false
	}
	newPassword = getScryptKey(newPassword, dbSalt)
	if err := setUserPassword(username, newPassword); err != nil {
		return false
	}
	return true
}

// if not find the user return (false, "") else return (-, username).
func Login(username, password string) (pass bool, name string) {
	p, s := getUserLogin(username)
	if s == "" || p == "" {
		logs.Debug("not find the user")
		return false, ""
	}
	if strings.Compare(getScryptKey(password, s), p) == 0 {
		return true, username
	}
	return false, username
}
