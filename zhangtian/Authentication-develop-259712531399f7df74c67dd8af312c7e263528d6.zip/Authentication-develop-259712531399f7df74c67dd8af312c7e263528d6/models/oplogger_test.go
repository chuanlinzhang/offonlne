package models

import (
	"testing"
	"time"
)

func TestAddNewOpLog(t *testing.T) {
	if err := AddNewOpLog("tab", time.Now(), "test op", "just a test"); err != nil {
		t.Error(err)
	}
	if err := AddNewOpLog("tab", time.Now(), "test op2", "just a test"); err != nil {
		t.Error(err)
	}
	if err := DeleteLog("tab"); err != nil {
		t.Error(err)
	}
	if err := AddNewOpLog(" ", time.Now(), "test op3", "just a test"); err == nil {
		t.Error("name is __")
	}
	if err := DeleteLog(""); err == nil {
		t.Error("name is empty")
	}

}
