package redisDB

import (
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/logs"
	"github.com/garyburd/redigo/redis"
	"time"
)

type redisDB struct {
	pool     *redis.Pool
	dbUrl    string
	dbNum    int
	password string
}

var DefaultDB *redisDB

type Conn struct {
	redis.Conn
}

func GetConn() (c redis.Conn, err error) {
	if DefaultDB.pool != nil {
		c = DefaultDB.pool.Get()
	} else {
		return coon()
	}
	return
}

func coon() (c redis.Conn, err error) {
	c, err = redis.Dial("tcp", DefaultDB.dbUrl)
	if err != nil {
		return nil, err
	}
	if DefaultDB.password != "" {
		if _, err := c.Do("AUTH", DefaultDB.password); err != nil {
			c.Close()
			return nil, err
		}
	}
	_, selecterr := c.Do("SELECT", DefaultDB.dbNum)
	if selecterr != nil {
		c.Close()
		return nil, selecterr
	}
	return
}

func init() {
	url := beego.AppConfig.String("redis::url")
	if url == "" {
		//url = "111.231.215.178:6379"
		panic("error not set redis url")
	}
	dbNum, err := beego.AppConfig.Int("redis::dbNum")
	if err != nil {
		dbNum = 0
		logs.Info("Use default redis dbNum 0")
	}
	passeord := beego.AppConfig.String("redis::password")

	useRedisPool, err := beego.AppConfig.Bool("redis::usePool")
	if err != nil {
		useRedisPool = true
		logs.Info("use redis pool")
	}
	DefaultDB = &redisDB{
		dbUrl:    url,
		dbNum:    dbNum,
		password: passeord,
	}
	if useRedisPool {
		maxIdle, err := beego.AppConfig.Int("redis::maxIdle")
		if err != nil {
			maxIdle = 3
		}
		idleTimeout, err := beego.AppConfig.Int64("redis::idleTimeout")
		if err != nil {
			idleTimeout = 180
		}
		// initialize a new pool
		DefaultDB.pool = &redis.Pool{
			MaxIdle:     maxIdle,
			IdleTimeout: time.Duration(idleTimeout) * time.Second,
			Dial:        coon,
		}
	}
}
