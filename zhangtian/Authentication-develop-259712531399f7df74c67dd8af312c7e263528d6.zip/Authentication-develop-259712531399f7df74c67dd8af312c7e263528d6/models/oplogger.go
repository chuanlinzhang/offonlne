package models

import (
	"etecity/Authentication/models/mongodb"
	"fmt"
	"github.com/astaxie/beego"
	"strings"
	"time"
)

type userOpLog struct {
	Username string `bson:"-"`
	Time     string `bson:"time"`
	Op       string `bson:"op"`
	Detail   string `bson:"detail"`
}

// Mongodb config
var (
	DBName          = "userOpLogs"
	OpLogTimeFormat = "2006-01-02 15:04:05 MST"
)

func init() {
	dn := beego.AppConfig.String("mongodb::dbname")
	if dn != "" {
		DBName = strings.TrimSpace(dn)
	}
	of := beego.AppConfig.String("mongodb::logtimeformat")
	if of != "" {
		OpLogTimeFormat = strings.TrimSpace(of)
	}
}

// AddNewOpLog add a new operation log to db.
func AddNewOpLog(name string, time time.Time, op, detail string) error {
	nLog := &userOpLog{
		Username: strings.TrimSpace(name),
		Time:     time.Format(OpLogTimeFormat),
		Op:       strings.TrimSpace(op),
		Detail:   strings.TrimSpace(detail),
	}
	return nLog.write()
}

func DropOpLogs(name string) error {
	if name == "" {
		return fmt.Errorf("username can not be empty")
	}
	conn := mongodb.Conn()
	defer conn.Close()
	c := conn.DB(DBName).C(name)
	return c.DropCollection()
}

// write write a opLog to dbName.username.
func (ol *userOpLog) write() error {
	if ol.Username == "" {
		return fmt.Errorf("username can not be empty")
	}
	conn := mongodb.Conn()
	defer conn.Close()
	c := conn.DB(DBName).C(ol.Username)
	if err := c.Insert(ol); err != nil {
		return fmt.Errorf("insert to %s.%s fail: %v", DBName, ol.Username, err)
	}
	return nil
}

// DeleteLog delete someone all opLogs.
func DeleteLog(username string) error {
	if username == "" {
		return fmt.Errorf("username can not be empty")
	}
	conn := mongodb.Conn()
	defer conn.Close()
	c := conn.DB(DBName).C(username)
	if err := c.DropCollection(); err != nil {
		return fmt.Errorf("drop %s.%s failed: %v", DBName, username, err)
	}
	return nil
}
