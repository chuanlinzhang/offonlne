package mongodb

import (
	"github.com/astaxie/beego"
	"gopkg.in/mgo.v2"
)

var (
	DBUrl  string
	DBName string
	CName  string
)

var session *mgo.Session

// Conn return mongodb session.
func Conn() *mgo.Session {
	return session.Copy()
}

func init() {
	DBUrl = beego.AppConfig.String("mongodb::url")
	if DBUrl == "" {
		//DBUrl = "mongodb://111.231.215.178:27017"
		panic("Please config the url for mongodb")
	}
	sess, err := mgo.Dial(DBUrl)
	if err != nil {
		panic(err)
	}

	session = sess
	session.SetMode(mgo.Monotonic, true)
}
